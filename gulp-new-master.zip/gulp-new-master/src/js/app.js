import * as mainFuncs from "./modules/functions.js";
mainFuncs.isWebp();

import Swiper, { Navigation, Pagination } from 'swiper';
const swiper=new Swiper();